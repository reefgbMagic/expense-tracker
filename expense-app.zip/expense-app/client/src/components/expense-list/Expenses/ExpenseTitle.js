import React from "react";

function ExpenseTitle(){}

export default ExpenseTitle
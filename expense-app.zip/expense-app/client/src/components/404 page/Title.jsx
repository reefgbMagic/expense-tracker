const Title = ({titleContent}) => {
    return (
        <h1>{titleContent}</h1>
    )
}
export default Title;
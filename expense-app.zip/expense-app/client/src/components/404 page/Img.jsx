import React from "react";

const Img = () => {

    return (
        <img
            src="https://img.freepik.com/free-vector/sloth-being-really-sad_75487-767.jpg?w=1380&t=st=1676965411~exp=1676966011~hmac=24be9a94496a5d07414017d3e78362c40794bd78e6173122e486fe55a024ef7b"
            alt="not-found-picture"/>
    )
}
export default Img;
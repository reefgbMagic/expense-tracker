export const Title = ({titleText, user}) => {

    return (<h1>{titleText}{user}</h1>)
};